﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator_Form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int results = 0;

            byte number1 = 0, number2 = 0;

            try
            {
                number1 = Convert.ToByte(textBox1.Text);

                try
                {
                    number2 = Convert.ToByte(textBox2.Text);

                    results = number1 + number2;
                    textBox3.Text = results.ToString();

                    results = number1 - number2;
                    textBox4.Text = results.ToString();

                    results = number1 * number2;
                    textBox5.Text = results.ToString();

                    results = number1 / number2;
                    textBox6.Text = results.ToString();

                }

                catch(Exception a)
                {
                    MessageBox.Show("\nYou Have Entered Wrong Data In Place Of Number 2!\n", a.Message);
                    textBox2.Focus();
                }
            }

            catch (Exception a)
            {
                 MessageBox.Show("\nYou Have Entered Wrong Data In Place Of Number 1!\n", a.Message);
                textBox1.Focus();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do You Want To Exit The Application?", "Exit" , MessageBoxButtons.YesNo).ToString() == "Yes")
            {
                this.Close();
            }
        }
    }
}
